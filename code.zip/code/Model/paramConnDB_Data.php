<?php

//Datos de configuración de la conexión a la base de datos
//Servidor
//$host='localhost';
//$host= '127.0.0.1';
//$host='mysql.hostinger.es';
$host = 'toinvoice.org.mysql';

//Usuario
//$user='root';
$user = 'toinvoice_org';

//Password
//$password='root';
$password = 'GkgRh4QU';

//Base de datos a utilizar
//$db='cliente';
$db = 'toinvoice_org';
