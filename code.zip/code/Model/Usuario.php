<?php

require_once __DIR__ . '/ConnClienteDB.php';

class Usuario {
  private $iduser;
  private $username;
  private $password;
  
  function __construct($iduser, $username, $password) {
    $this->iduser = $iduser;
    $this->username = $username;
    $this->password = $password;
  }

  public function getIduser() {
      return $this->iduser;
  }

  public function getUsername() {
      return $this->username;
  }

  public function getPassword() {
      return $this->password;
  }

  public function setIduser($iduser) {
      $this->iduser = $iduser;
  }

  public function setUsername($username) {
      $this->username = $username;
  }

  public function setPassword($password) {
      $this->password = $password;
  }
  
  public static function compruebaLogin($username, $password) {
   
     $conexion = ConnClienteDB::connectDB();
    $seleccion = "SELECT iduser, username, password FROM usuario WHERE username = '$username'";
    $consulta = $conexion->query($seleccion);
    
    $registro = $consulta->fetchObject();
    
    if ($registro->password == $password){
        $respuesta = TRUE;
    }else {
        $respuesta = FALSE;
    }
    
    
   // $usuario = new Usuario($registro->iduser, $registro->username, $registro->password);
    //var_dump($usuario);
    return $respuesta;  
  }


}   