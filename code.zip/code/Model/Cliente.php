<?php

require_once __DIR__ . '/ConnClienteDB.php';

class Cliente {
  private $idcli;
  private $nomcli;
  private $apecli;
  private $dnicli;
  private $domcli;
  private $emailcli;
  private $telcli;
  private $faltacli;
  private $idclub;
  private $fnaccli;
  private $contcli;
  private $nomclub;
  
  function __construct($idcli = "", $nomcli = "", $apecli = "", $dnicli = "", $domcli = "", $emailcli = "", $telcli = "", $faltacli = "", $idclub = "", $fnaccli = "", $contcli = "", $nomclub = "") {
    $this->idcli = $idcli;
    $this->nomcli = $nomcli;
    $this->apecli = $apecli;
    $this->dnicli = $dnicli;
    $this->domcli = $domcli;
    $this->emailcli = $emailcli;
    $this->telcli = $telcli;
    $this->faltacli = $faltacli;
    $this->idclub = $idclub;
    $this->fnaccli = $fnaccli;
    $this->contcli = $contcli;
    $this->nomclub = $nomclub;
  }


  public function getIdcli() {
      return $this->idcli;
  }

  public function getNomcli() {
      return $this->nomcli;
  }

  public function getApecli() {
      return $this->apecli;
  }

  public function getDnicli() {
      return $this->dnicli;
  }

  public function getDomcli() {
      return $this->domcli;
  }

  public function getEmailcli() {
      return $this->emailcli;
  }

  public function getTelcli() {
      return $this->telcli;
  }
  
  public function getFaltacli() {
      return $this->faltacli;
  }
  
  public function getIdclub() {
      return $this->idclub;
  }
  
  public function getFnaccli() {
      return $this->fnaccli;
  }
  
  public function getContcli() {
      return $this->contcli;
  }
  
  public function getNomclub() {
      return $this->nomclub;
  }

  public function setIdcli($idcli) {
      $this->idcli = $idcli;
  }

  public function setNomcli($nomcli) {
      $this->nomcli = $nomcli;
  }

  public function setApecli($apecli) {
      $this->apecli = $apecli;
  }

  public function setDnicli($dnicli) {
      $this->dni = $dnicli;
  }

  public function setDomcli($domcli) {
      $this->domcli = $domcli;
  }

  public function setEmailcli($emailcli) {
      $this->emailcli = $emailcli;
  }

  public function setTelcli($telcli) {
      $this->telcli = $telcli;
  }
  
   public function setFaltacli($faltacli) {
      $this->faltacli = $faltacli;
  }

  public function setIdclub($idclub) {
      $this->idclub = $idclub;
  }
  
  public function setFnaccli($fnaccli) {
      $this->fnaccli = $fnaccli;
  }
  
  public function setContcli($contcli) {
      $this->contcli = $contcli;
  }
  
  public function setNomclub($nomclub) {
      $this->nomclub = $nomclub;
  }
  
  public function insert() {
    $conexion = ConnClienteDB::connectDB();
    $insercion = "INSERT INTO clientes (idcli, nomcli, apecli, dnicli, domcli, "
            . "emailcli, telcli, faltacli, idclub, fnaccli, contcli) "
            . "VALUES (\"\",\"".$this->nomcli."\",\"".$this->apecli."\", \"".$this->dnicli."\","
            . "\"".$this->domcli."\", \"".$this->emailcli."\", \"".$this->telcli."\","
            . "\"".date('Y-m-d',strtotime(str_replace("/", "-",$this->faltacli)))."\","
            . "\"".$this->idclub."\","
            . "\"".date('Y-m-d',strtotime(str_replace("/", "-",$this->fnaccli)))."\","
            . " \"".$this->contcli."\")";
    
    /*.date('Y/m/d',strtotime(str_replace("/", "-",$this->fnaccli))).*/
    
  
    $conexion->exec($insercion);
  }
  
  public function update() {
    $conexion = ConnClienteDB::connectDB();
    $actualizar = "UPDATE clientes SET idcli='$this->idcli', nomcli='$this->nomcli',"
            . "apecli='$this->apecli', dnicli='$this->dnicli', domcli='$this->domcli', "
            . "emailcli='$this->emailcli', telcli='$this->telcli',"
            . "faltacli='".date('Y-m-d',strtotime(str_replace("/", "-",$this->faltacli)))."', "
            . "idclub='$this->idclub', "
            . "fnaccli='".date('Y-m-d',strtotime(str_replace("/", "-",$this->fnaccli)))."', "
            . "contcli='$this->contcli' WHERE idcli='$this->idcli'";
    
    $conexion->exec($actualizar);
  }  

  public function delete($idcli) {
    $conexion = ConnClienteDB::connectDB();
    $borrado = "DELETE FROM clientes WHERE idcli=$idcli";
    
    $conexion->exec($borrado);
  }
  
   public static function getClientes($offset, $limit) {
    $conexion = ConnClienteDB::connectDB();
    //$seleccion = "SELECT idcli, nomcli, apecli, dnicli, domcli, emailcli, telcli, faltacli, idclub, fnaccli, contcli FROM clientes";
   
  //  $seleccion = "SELECT SQL_CALC_FOUND_ROWS idcli, nomcli, apecli, dnicli, domcli, emailcli, telcli, faltacli, idclub, fnaccli, contcli FROM clientes LIMIT $offset, $limit";
    $seleccion = "SELECT SQL_CALC_FOUND_ROWS idcli, nomcli, apecli, dnicli, domcli,"
            . " emailcli, telcli, faltacli, clientes.idclub, fnaccli, contcli, "
            . "club.nomclub as nomclub FROM clientes INNER JOIN club ON"
            . " clientes.idclub = club.idclub ORDER BY idcli LIMIT $offset, $limit";
   
    $consulta = $conexion->query($seleccion);
    
    $sqlTotal = $conexion->query("SELECT FOUND_ROWS()");
   
    $total = $sqlTotal->fetchColumn();
    if ($total){
          while ($registro = $consulta->fetchObject()) {
          $clientes[] = new Cliente($registro->idcli, $registro->nomcli,  $registro->apecli,
                  $registro->dnicli,  $registro->domcli,  $registro->emailcli, $registro->telcli, $registro->faltacli,
                  $registro->idclub, $registro->fnaccli, $registro->contcli, $registro->nomclub);
        }
    }
        $datos = ['total' => $total,
                   'clientes' => $clientes    
                 ];
    
    return $datos;    
  }
  
  
  public static function getClienteById($idcli) {
    $conexion = ConnClienteDB::connectDB();
    $seleccion = "SELECT idcli, nomcli, apecli, dnicli, domcli, emailcli, telcli, faltacli, clientes.idclub, fnaccli, contcli, club.nomclub as nomclub FROM clientes INNER JOIN club ON"
            . " clientes.idclub = club.idclub WHERE idcli=$idcli";
    
    $consulta = $conexion->query($seleccion);
    $registro = $consulta->fetchObject();
    $cliente = new Cliente($registro->idcli, $registro->nomcli,  $registro->apecli,
              $registro->dnicli,  $registro->domcli,  $registro->emailcli, $registro->telcli, $registro->faltacli,
              $registro->idclub, $registro->fnaccli, $registro->contcli, $registro->nomclub);
    return $cliente;    
  }
  
  public static function setCantidadById($idcli, $cantidad) {
    $conexion = ConnClienteDB::connectDB();
    $actualizar = "UPDATE clientes SET contcli='$cantidad' WHERE idcli='$idcli'";
    echo $actualizar;
    $conexion->exec($actualizar);
    
    
  } 
  
  public static function datosGrafica() {
      
    $conexion = ConnClienteDB::connectDB();
    $seleccion = "SELECT COUNT(IF(contcli = 0, 1, NULL)) AS cero, COUNT(IF(contcli = 1, 1, NULL)) AS uno, COUNT(IF(contcli = 2, 1, NULL)) AS dos, COUNT(IF(contcli = 3, 1, NULL)) AS tres, COUNT(IF(contcli = 4, 1, NULL)) AS cuatro, COUNT(IF(contcli = 5, 1, NULL)) AS cinco, COUNT(IF(contcli = 6, 1, NULL)) AS seis, COUNT(IF(contcli = 7, 1, NULL)) AS siete, COUNT(IF(contcli = 8, 1, NULL)) AS ocho, COUNT(IF(contcli = 9, 1, NULL)) AS nueve, COUNT(IF(contcli = 10, 1, NULL)) AS diez FROM clientes";
   
    $consulta = $conexion->query($seleccion);
    //$resultado = $consulta->fetchAll(PDO::FETCH_ASSOC);
    $resultado = $consulta->fetchAll(PDO::FETCH_BOTH);
     
   return $resultado;
      
  }
  
  public static function buscar($offset, $limit, $busqueda) {
      
    $conexion = ConnClienteDB::connectDB();
    $seleccion = "SELECT SQL_CALC_FOUND_ROWS idcli, nomcli, apecli, dnicli, domcli,"
            . " emailcli, telcli, faltacli, clientes.idclub, fnaccli, contcli, "
            . " club.nomclub as nomclub FROM clientes INNER JOIN club ON clientes.idclub = club.idclub "
            . " WHERE nomcli LIKE '%".$busqueda."%' OR apecli LIKE '%".$busqueda."%'  OR"
            . " dnicli LIKE '%".$busqueda."%' OR domcli LIKE '%".$busqueda."%' OR"
            . " emailcli LIKE '%".$busqueda."%' OR telcli LIKE '%".$busqueda."%' LIMIT $offset, $limit";
    
    $consulta = $conexion->query($seleccion);
        
    $sqlTotal = $conexion->query("SELECT FOUND_ROWS()");
   
    $total = $sqlTotal->fetchColumn();
        if($total){
              while ($registro = $consulta->fetchObject()) {
              $clientes[] = new Cliente($registro->idcli, $registro->nomcli,  $registro->apecli,
                      $registro->dnicli,  $registro->domcli,  $registro->emailcli, $registro->telcli, $registro->faltacli,
                      $registro->idclub, $registro->fnaccli, $registro->contcli, $registro->nomclub);
                }
        }
        $datos = ['total' => $total,
                   'clientes' => $clientes    
                 ];
    
    return $datos;  
      
  }
  
}
