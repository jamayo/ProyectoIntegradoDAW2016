<?php
//require 'ParamConnDB_class.php';
require __DIR__ . '/ParamConnDB_Class.php';
abstract class ConnClienteDB {
  
  /*private $servidor;
    private $usuario;
    private $password;
    private $base_datos;
    private $conn; 
  */

  public static function connectDB() {
    $conf = ParamConnDB_Class::getInstance();
    $servidor=$conf->getHostDB();
    $base_datos=$conf->getDB();
    $usuario=$conf->getUserDB();
    $password=$conf->getPassDB();
    
    try {
      $connection = new PDO("mysql:host=$servidor;dbname=$base_datos;charset=utf8", $usuario, $password);
  
    } catch (PDOException $e) {
      echo "No se ha podido establecer conexión con el servidor de bases de datos.<br>";
      die ("Error: " . $e->getMessage());
    }
    return $connection;
  }
}
