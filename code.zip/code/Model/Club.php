<?php

require_once __DIR__ . '/ConnClienteDB.php';

class Club {
  private $idclub;
  private $nomclub;
  
  
  function __construct($idclub, $nomclub) {
    $this->idclub = $idclub;
    $this->nomclub = $nomclub;
    
  }

  public function getIdclub() {
      return $this->idclub;
  }

  public function getNomclub() {
      return $this->nomclub;
  }

  public function getDomclub() {
      return $this->domclub;
  }

  public function getEmailclub() {
      return $this->emailclub;
  }

  public function getTelclub() {
      return $this->telclub;
  }

  public function setIdclub($idclub) {
      $this->idclub = $idclub;
  }

  public function setNomclub($nomclub) {
      $this->nomclub = $nomclub;
  }

  public function setDomclub($domclub) {
      $this->domclub = $domclub;
  }

  public function setEmailclub($emailclub) {
      $this->emailclub = $emailclub;
  }

  public function setTelclub($telclub) {
      $this->telclub = $telclub;
  }

  
  public function insert() {
    $conexion = ConnClienteDB::connectDB();
    $insercion = "INSERT INTO club (idclub, nomclub, domclub, "
            . "emailclub, telclub) VALUES ('', "
            . "\"".$this->nomclub."\", \"".$this->domclub."\","
            . " \"".$this->emailclub."\", \"".$this->telclub."\")";
    
    //echo $insercion;
    $conexion->exec($insercion);
  }
  
  public function update() {
    $conexion = ConnClienteDB::connectDB();
    $actualizar = "UPDATE club SET idclub='$this->idclub', nomclub='$this->nomclub', domclub='$this->domclub', "
            . "emailclub='$this->emailclub', telclub='$this->telclub' WHERE idclub='$this->idclub'";
    $conexion->exec($actualizar);
  }  

  public function delete($idclub) {
    $conexion = ConnClienteDB::connectDB();
    $borrado = "DELETE FROM club WHERE idclub=$idclub";
    echo $borrado;
    $conexion->exec($borrado);
  }
  
    public static function getListaClubes() {
    $conexion = ConnClienteDB::connectDB();
    $seleccion = "SELECT idclub, nomclub FROM club";
    $consulta = $conexion->query($seleccion);
    $clubes = [];
    
    while ($registro = $consulta->fetchObject()) {
        
      $clubes[] = new Club($registro->idclub, $registro->nomclub);
      
    }
    
    return $clubes;    
  }
  
  public static function getClubes($offset, $limit) {
    $conexion = ConnClienteDB::connectDB(); 
    $seleccion = "SELECT SQL_CALC_FOUND_ROWS idclub, nomclub, domclub, emailclub, telclub FROM club LIMIT $offset, $limit";
    $consulta = $conexion->query($seleccion);
    $sqlTotal = $conexion->query("SELECT FOUND_ROWS()");
    $total = $sqlTotal->fetchColumn();
    $clubes = [];
    
    while ($registro = $consulta->fetchObject()) {
      $clubes[] = new Club($registro->idclub, $registro->nomclub,
              $registro->domclub,  $registro->emailclub, $registro->telclub);
    }
    $datos = ['total' => $total,
              'clubes' => $clubes    
              ];

    return $datos;    
  }
  
  public static function getClubesById($idclub) {
    $conexion = ConnClienteDB::connectDB();
    $seleccion = "SELECT idclub, nomclub, domclub, emailclub, telclub FROM club WHERE idclub=$idclub";
    $consulta = $conexion->query($seleccion);
    $registro = $consulta->fetchObject();
    $club = new Club($registro->idclub, $registro->nomclub, $registro->domclub, 
            $registro->emailclub, $registro->telclub);
    return $club;    
  }
}
