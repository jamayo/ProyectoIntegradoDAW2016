<?php

class ParamConnDB_Class {
  private $_userdb;
  private $_passdb;
  private $_hostdb;
  private $_db;

  static $_instance;

  private function __construct(){
    require __DIR__ . '/paramConnDB_Data.php';
    $this->_userdb=$user;
    $this->_passdb=$password;
    $this->_hostdb=$host;
    $this->_db=$db;
  }

  private function __clone(){ }  //evito el clonado de la conexión

  public static function getInstance(){
     //if (!(self::$_instance instanceof self)){  //permito solo una instancia de conexion a DB
        self::$_instance=new self();
    // }
     return self::$_instance;
  }

  public function getUserDB(){
     $var=$this->_userdb;
     return $var;
  }

  public function getHostDB(){
     $var=$this->_hostdb;
     return $var;
  }

  public function getPassDB(){
     $var=$this->_passdb;
     return $var;
  }

  public function getDB(){
     $var=$this->_db;
     return $var;
  }

}

