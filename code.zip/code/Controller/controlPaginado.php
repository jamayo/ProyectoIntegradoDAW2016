<?php session_start(); ?>
<?php

  require_once __DIR__ . '/../Model/Cliente.php';
  
   //Control PAGINA seleccionada/defecto
  if (!isset($_POST['pag'])) {
    if (!isset($_SESSION['pag'])){
      $_SESSION['pag'] = 1;
    }
  }else {
    $_SESSION['pag'] = $_POST['pag'];
  };
 
  //Control LIMITE seleccionado/defecto
  if (!isset($_POST['limit'])) {
    if (!isset($_SESSION['limit'])){
      $_SESSION['limit'] = 8;
    }
  }else {
    $_SESSION['limit'] = $_POST['limit'];
  };
  if ($_SESSION['pag']<=0) {
      $_SESSION['pag']=1;
  }
  $offset = ($_SESSION['pag']-1) * $_SESSION['limit'];
  //echo $_SESSION['pag'];
  
  $datos = Cliente::getClientes($offset, $_SESSION['limit']);
  
  $datos['totalPag'] = ceil($datos['total']/$_SESSION['limit']);
  
  //Comprobación paginación no quede fuera de rango por cambio de límite del usuario.
  
  if ($datos['totalPag'] < $_SESSION['pag']) {
     
    $_SESSION['pag'] = $datos['totalPag'];
    $offset = ($_SESSION['pag']-1) * $_SESSION['limit'];
    //$datos = [];
    
    $datos = Cliente::getClientes($offset, $_SESSION['limit']);
    
    $datos['totalPag'] = ceil($datos['total']/$_SESSION['limit']);
    
    
  }
  $datos['pag'] = $_SESSION['pag'];
  $datos['limit'] = $_SESSION['limit'];

  
  //echo $twig->render('paginado.html.twig', $datos);  TWIG