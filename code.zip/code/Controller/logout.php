<?php session_start(); ?>
<?php

$_SESSION['username']= NULL;
$_SESSION['login'] = NULL;
//unset ($_SESSION['username']);
//unset ($_SESSION['login']);
session_destroy();
$navegador = true;

if ($msgloginerror){
    $navegador = false;
}

//$parametros_cookies = session_get_cookie_params(); 
//setcookie(session_name(),0,1,$parametros_cookies["path"]);
//echo "logout realizado";

sleep(2);

require __DIR__ . '/index.php';