<?php session_start(); ?>
<?php

  // Carga la vista del formulario de alta de habitación
  require_once 'twig/lib/Twig/Autoloader.php';
  Twig_Autoloader::register();
  $loader = new Twig_Loader_Filesystem(__DIR__.'/../View/');
  $twig = new Twig_Environment($loader);
  
  require_once __DIR__ . '/../Model/Cliente.php';
  require_once __DIR__ . '/../Model/Club.php';
  
 
  $cliente = Cliente::getClienteById($_GET['idcli']);
  $clubes = Club::getListaClubes();
  //var_dump($clubes);
  //echo $twig->render('actualizaCliente.html.twig', ["cliente" => $cliente]);
  //echo $twig->render('formularioCliente.html.twig', ["cliente" => $cliente]);
  echo $twig->render('formularioCliente.html.twig', ["cliente" => $cliente, "clubes" => $clubes, "accion" => "modificar"]);