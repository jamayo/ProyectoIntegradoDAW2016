<?php session_start(); ?>
<?php
  require_once __DIR__ . '/../Model/Cliente.php';

  Cliente::setCantidadById($_POST['idcli'], $_POST['cantidad']);

  
  
  
  //header("Location: consultaRoom.php"); 
  //la aplicación de ajax en la eliminación de un registro, hace innecesaria 
  //llamar a consultaRoom.php para una nueva consulta, por tanto comento la linea.