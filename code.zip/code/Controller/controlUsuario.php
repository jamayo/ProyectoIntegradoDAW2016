<?php session_start(); ?>
<?php

require_once 'twig/lib/Twig/Autoloader.php';
  Twig_Autoloader::register();
  $loader = new Twig_Loader_Filesystem(__DIR__.'/../View/');
  $twig = new Twig_Environment($loader);  
  
  // Carga la vista de inicio
  //echo $twig->render('inicio.html.twig', []);
 

  require_once __DIR__ . '/../Model/Usuario.php';
 


    if ($_POST['username'] && $_POST['password']) {
    //Comprobacion del envio del nombre de usuario y password
        $username = $_POST['username'];
        $password = $_POST['password'];
       
        if ($password == NULL) {
            echo "Introduce el password";
        } else {

           $login = Usuario::compruebaLogin($username, $password);
          
           

            if (!$login) {
                $msgloginerror = true;
                //echo "Login incorrecto";
                
                require_once __DIR__ . '/../Controller/logout.php';
                //require_once '../Controller/index.php';
                
            } else {
               
                $_SESSION['username'] = $username;
                $_SESSION['login'] = true;
                $msgloginerror = false;
                $navegador = false;
                //echo "Login correcto como usuario: " . $_SESSION['username']. "login es " .$_SESSION['login']; ;
                //header("Location: consultaCliente.php");
                sleep(1.5);
                require_once __DIR__ . '/../Controller/consultaCliente.php';
                //echo $twig->render('listado.html.twig', []);
            }
        }
    } else {
        
    }
    