<?php session_start(); ?>
<?php
  require_once __DIR__ . '/../Model/Cliente.php';

 
  $clienteActualiza = new Cliente($_POST['idcli'], $_POST['nomcli'],$_POST['apecli'],
          $_POST['dnicli'], $_POST['domcli'], $_POST['emailcli'], $_POST['telcli'], 
          $_POST['faltacli'], $_POST['idclub'], $_POST['fnaccli'], $_POST['contcli'], "");
  

  $clienteActualiza->update();
  
  header("Location: consultaCliente.php");