<?php session_start(); ?>
<?php

  // Carga la vista del formulario de alta de habitación
  require_once 'twig/lib/Twig/Autoloader.php';
  Twig_Autoloader::register();
  $loader = new Twig_Loader_Filesystem(__DIR__.'/../View/');
  $twig = new Twig_Environment($loader);
  require_once __DIR__ . '/../Model/Cliente.php';
  require_once __DIR__ . '/../Model/Club.php';
  
  $clubes = Club::getListaClubes();
  
  
  echo $twig->render('formularioCliente.html.twig', ["clubes" => $clubes]);
