<?php
  require_once __DIR__ . '/../Model/Cliente.php';

  // inserta la registro en la base de datos
  $clienteAlta = new Cliente("", $_POST['nomcli'], $_POST['apecli'], $_POST['dnicli'],
          $_POST['domcli'], $_POST['emailcli'], $_POST['telcli'], $_POST['faltacli'], 
          $_POST['idclub'], $_POST['fnaccli'], $_POST['contcli'], "");
  
  $clienteAlta->insert();

   header("Location: consultaCliente.php");