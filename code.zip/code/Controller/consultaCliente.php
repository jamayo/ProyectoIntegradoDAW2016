<?php session_start(); ?>
<?php


if ($_SESSION["login"] === true){

  require_once 'twig/lib/Twig/Autoloader.php';
  Twig_Autoloader::register();
  $loader = new Twig_Loader_Filesystem(__DIR__.'/../View/');
  $twig = new Twig_Environment($loader);

  require_once __DIR__ . '/controlPaginado.php';



  echo $twig->render('listado.html.twig', $datos);
}else {
    echo $twig->render('inicio.html.twig', []);
    
}
